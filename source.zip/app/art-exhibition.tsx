export const paperImages = [
'https://pbs.twimg.com/media/HOJ5OBraYAAudMG?format=jpg&name=900x900',
'https://pbs.twimg.com/media/HOJ5RbkaYAAmbS0?format=jpg&name=900x900',
'https://pbs.twimg.com/media/HOJ5oR4bAAA7qVS?format=jpg&name=900x900',
'https://pbs.twimg.com/media/HOJ5qfdaMAAsHQE?format=jpg&name=900x900'
];
export default function ArtExhibition(){return <section id="creations" className="art-exhibition"><div className="section-heading"><div><p className="eyebrow">THE CREATIVE GALLERY / 03</p><h2>纸上，另一个世界<span>。</span></h2></div><p>我的创作作品展览<br/><span>中式古典 · 立体剪纸 · 人物图集</span></p></div><div className="paper-gallery">{paperImages.map((src,i)=><a key={src} href={src} target="_blank" rel="noreferrer" aria-label={'查看中式古典立体剪纸作品 '+(i+1)+' 大图'}><img src={src} alt={'中式古典立体剪纸人物作品 '+(i+1)} loading="lazy"/><span>0{i+1} / PAPER ART <b>↗</b></span></a>)}</div><div className="exhibition-caption"><div><h3>中式古典立体剪纸</h3><p>从一组剪纸艺术中获得灵感，我把它延伸成可替换人物、手持物、背景、服饰与头饰的通用提示词。让同一种纸艺语言，展开不同的古典想象。</p></div><a className="solid-link" href="/posts/chinese-paper-art">作品与创作笔记 ↗</a></div></section>}
