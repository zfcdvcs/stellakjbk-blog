export type Post = {slug:string;category:string;title:string;image:string|null;alt:string;summary:string;paragraphs:string[];source:string;original:string|null;sourceName:string;kind:string;date?:string;views?:number;likes?:number;reposts?:number;bookmarks?:number;sections?:{title:string;text:string}[];readLabel?:string;takeaways?:string[]};
const creativePosts:Post[] = [
{slug:'food-miniatures',category:'微缩美食',title:'让食材成为主角：餐桌上的微型世界',image:'/images/food.jpg',alt:'用生姜的天然纹理表现自由女神造型的 AI 创作示例',summary:'从姜皮、纤维到切面，让真实食材的质感构成一个微型角色。',paragraphs:['这组提示词把食材本身作为角色的构成材料，让外皮、根须与切片承担服装和肢体的造型。画面保留自然纹理，以微距视角和柔和窗光表现餐桌上的微型世界。','可调整的要素包括食材、角色身份、动作和场景。公开收录页展示了生姜主题的创作示例，并提供中英文提示词。'],source:'https://www.jxxy.net/ai/prompts/image/prompt-image-jxxy-photorealistic-food-miniature-character-photography/',original:'https://x.com/Stellakjbk/status/2066024060560244936',sourceName:'觉醒AI · 公开收录',kind:'提示词笔记'},
{slug:'pastry-packaging',category:'品牌与包装',title:'一盒糕点，从品牌视觉到包装结构',image:'/images/pastry.jpg',alt:'绿色抹茶糕点礼盒的 AI 包装设计提案板',summary:'把礼盒效果图、展开结构和印刷工艺放进同一份设计提案。',paragraphs:['这份提示词围绕糕点包装展开，从品牌定位、用户与规格出发，组织主视觉、包装各面、内托、刀模、材料和工艺说明。','示例采用绿色礼盒与糕点组合，呈现品牌视觉如何延伸到不同包装部位。这里收录的是 AI 设计提案思路，图中文字与尺寸不等同于经过工程校验的生产文件。'],source:'https://www.jxxy.net/ai/prompts/image/prompt-image-jxxy-high-end-ecommerce-pastry-packaging-design-board/',original:'https://x.com/Stellakjbk/status/2062558095235260742',sourceName:'觉醒AI · 公开收录',kind:'设计笔记'},
{slug:'building-blocks',category:'产品设计',title:'把一座城堡，拆解成四页积木设计图册',image:'/images/blocks.jpg',alt:'霍格沃茨城堡积木的 AI 图册封面示例',summary:'从成品总览到模块拆解，用连续页面讲清楚一个复杂模型。',paragraphs:['这套提示词规划了四页图册：成品总览、多视图与尺寸、爆炸图与零件清单，以及装配流程。统一版式让复杂模型的信息按层次展开。','公开示例使用城堡积木主题。它适合研究多页设计表达和模块化描述；实际结构、零件数量与装配可行性仍需专业校验。'],source:'https://www.jxxy.net/ai/prompts/image/prompt-image-jxxy-high-end-interlocking-block-production-manual-prompts/',original:'https://x.com/Stellakjbk/status/2068663896173658614',sourceName:'觉醒AI · 公开收录',kind:'设计笔记'},
{slug:'tiny-food-world',category:'微缩美食',title:'小人国里的老妈蹄花',image:null,alt:'',summary:'把地方美食放大，让小人物参与烹饪、品尝和讲故事。',paragraphs:['公开帖子分享了以老妈蹄花为主题的小人国美食创作，并在评论中给出提示词。创作先参考食物的文化与真实质感，再安排人物、道具和海报文字。','这一条与食材拟人化不同：食物仍是场景的中心，小人物围绕它展开活动。'],source:'https://w.twstalker.com/Stellakjbk',original:null,sourceName:'TwStalker · 主页公开索引',kind:'创作短记'},
{slug:'animation-supper',category:'动漫创作',title:'童年动画与《最后的晚餐》',image:null,alt:'',summary:'一次将童年动画主题与经典画作构图联系起来的创作分享。',paragraphs:['公开索引收录了以童年动画和《最后的晚餐》为题的作品分享。作者提到提示词放在评论区。','目前可核对的索引未完整呈现对应图片和评论，因此此处只保留主题摘要；作品细节请以 X 账号原始内容为准。'],source:'https://w.twstalker.com/Stellakjbk',original:null,sourceName:'TwStalker · 主页公开索引',kind:'创作短记'}
];
export const longPosts:Post[]=[
  {
    "slug": "dgx-spark-ling",
    "category": "本地部署",
    "title": "单台 DGX Spark 跑 Ling 3.0 Flash MXFP4：一次实测记录",
    "summary": "从内存溢出和底层适配排错，到约 40 Token/s 的稳定生成。一次把性能、可比性和安全误报都讲清楚的部署复盘。",
    "date": "2026-08-18",
    "views": 86375,
    "likes": 90,
    "reposts": 65,
    "bookmarks": 42,
    "original": "https://x.com/Stellakjbk/status/2089639054916682076",
    "kind": "实测长文",
    "sections": [
      {
        "title": "这篇文章解决什么问题",
        "text": "128GB 统一内存的 DGX Spark，能否稳定运行 124B 级 MoE 模型？作者从官方路径遇到的内存溢出出发，记录了量化布局、推理后端与真实请求验证的区别。低激活参数量可以减少计算，却不意味着全部权重不需要驻留。"
      },
      {
        "title": "值得关注的实测结果",
        "text": "作者报告：单并发、四类任务、20 次正式请求全部完成，MXFP4 平均持续解码 39.95 Token/s，平均首块响应时间 0.211 秒。首次预热却耗时 47 秒，冷启动与稳定运行必须分开衡量。"
      },
      {
        "title": "为什么不能直接排模型名次",
        "text": "另外三套部署的解码均值分别为 34.92、14.89 和 9.94 Token/s。但提示词、思考模式、后端与日志完整度没有完全对齐，因此这些是本次部署的观测值，不是模型能力或硬件极限排名。"
      },
      {
        "title": "最有价值的排错经验",
        "text": "作者把下载完成、权重加载、接口就绪、首次计算成功和持续生成分成不同阶段。安全测试还发现了关键词判定的误报：未匹配拒绝短语，不等于输出有害内容；长时间生成完成率，也不等于安全通过率。"
      }
    ],
    "takeaways": [
      "先跑通真实请求，再扩大上下文与并发。",
      "将冷启动、首块延迟、持续解码和回答质量分别记录。",
      "保留服务端配置与原始日志，才有依据解释差异。"
    ],
    "image": null,
    "alt": "",
    "paragraphs": [],
    "source": "https://x.com/Stellakjbk/status/2089639054916682076",
    "sourceName": "X · 已读取原文",
    "readLabel": "长文导读"
  },
  {
    "slug": "fable5-review",
    "category": "模型评测",
    "title": "Fable 5 上手测评：能力上限、成本与策略怎么平衡",
    "summary": "从代码排错遭拦截，到多步骤任务迅速消耗额度，讨论重型模型是否适合作为个人开发者的日常主力。",
    "date": "2026-06-11",
    "views": 38479,
    "likes": 84,
    "reposts": 14,
    "bookmarks": 22,
    "original": "https://x.com/Stellakjbk/status/2064983139521597724",
    "kind": "评测长文",
    "sections": [
      {
        "title": "评测的出发点",
        "text": "这篇文章没有停在模型榜单，而是把产品定位与个人任务体验放在一起。作者关心的是：更高的能力上限，是否值得更大的等待时间、调用开销和使用限制。"
      },
      {
        "title": "两个开发任务带来的落差",
        "text": "作者记录，一次针对 OpenClaw 的排错请求被安全机制拦截；另一次任务分管项目刚进入工作流，就耗尽了起始的 8 美元额度。它们属于个人测试经历，不能据此推算所有任务的失败率或统一成本。"
      },
      {
        "title": "评测真正值得保留的维度",
        "text": "文章将能力、速度、成本和策略放到同一张决策清单里。对于智能体项目，单次调用价格之外，分支任务数量和连续调用轮数也会影响总开销。一次昂贵但成功的运行，仍需要结合实际交付价值判断。"
      },
      {
        "title": "阅读时注意时间背景",
        "text": "原文发表于 2026 年 6 月，包含当时的套餐、价格及第三方服务介绍。本站保留的是评测思路与作者体验，不把历史活动或产品限制当成今天仍有效的使用条件。"
      }
    ],
    "takeaways": [
      "先用自己的典型任务验证，再决定是否作为主力。",
      "评估完整任务的成本，而不只比较模型单价。",
      "把工具拦截、输出质量与预算消耗分别记录。"
    ],
    "image": null,
    "alt": "",
    "paragraphs": [],
    "source": "https://x.com/Stellakjbk/status/2064983139521597724",
    "sourceName": "X · 已读取原文",
    "readLabel": "长文导读"
  },
  {
    "slug": "claude-code-workflows",
    "category": "Agent 工作流",
    "title": "Claude Code 新功能体验：快速模型 + 动态工作流",
    "summary": "围绕一个电商设计 Skill 的实际制作过程，观察任务自动推进、必要信息补充，以及效率与预算之间的关系。",
    "date": "2026-05-29",
    "views": 37902,
    "likes": 86,
    "reposts": 16,
    "bookmarks": 57,
    "original": "https://x.com/Stellakjbk/status/2060187282687266826",
    "kind": "工作流长文",
    "sections": [
      {
        "title": "从一次请求到连续工作",
        "text": "作者以快速模式与动态工作流为切入点，尝试让 Claude Code 自行规划并推进任务。关注点从单轮回答速度，转向一个多步骤项目能否在较少人工介入下完成。"
      },
      {
        "title": "实际做了什么",
        "text": "文中使用“产品电商总图”提示词 Skill 作为案例。作者描述，大部分步骤由系统继续执行，只在需要即梦 CLI 接入信息时补充材料。这提供了一个具体观察角度：工具信息是否齐全，会直接影响自动化能走多远。"
      },
      {
        "title": "效率之外，还有预算",
        "text": "作者尝试组合快速模式与动态工作流，希望提高推进速度，同时控制开销；实际使用感受仍是 Token 消耗明显。文章的实用价值在于提醒读者同时观察任务完成度、人工介入次数和总体消耗。"
      },
      {
        "title": "把它当作历史体验记录",
        "text": "原文包含当时的启动方式、套餐范围和第三方 API 服务介绍。此处不把这些条件转写为当前官方教程，也不沿用原文中未经独立确认的封号原因推测。"
      }
    ],
    "takeaways": [
      "用有明确产物的任务观察工作流，而非只看演示。",
      "提前准备必要的工具说明和接入信息。",
      "自动推进减少操作次数，也可能增加连续调用量。"
    ],
    "image": null,
    "alt": "",
    "paragraphs": [],
    "source": "https://x.com/Stellakjbk/status/2060187282687266826",
    "sourceName": "X · 已读取原文",
    "readLabel": "长文导读"
  },
  {
    "slug": "agent-work-market",
    "category": "Agent 工作流",
    "title": "从游戏界面到接单系统：让 Agent 团队完成真实交付",
    "summary": "一个 AI 接单社区原型，把需求发布、任务拆分、执行、成果合并和结算放进同一条流程。",
    "date": "2026-05-14",
    "views": 24569,
    "likes": 63,
    "reposts": 12,
    "bookmarks": 23,
    "original": "https://x.com/Stellakjbk/status/2054837461336166480",
    "kind": "项目长文",
    "sections": [
      {
        "title": "从哪里开始",
        "text": "作者先做了一个宝可梦风格的游戏页面，后来从接单平台获得启发，尝试把视觉场景改造成 AI 工作社区。文章关注的不只是角色会不会动，而是系统能不能承接任务并交付结果。"
      },
      {
        "title": "三层分工对应三类责任",
        "text": "原型把接单大楼划成三层：底层接收用户需求，中间层拆分任务并汇总结果，上层由不同 AI 执行专项工作。系统设想兼容 OpenClaw 与 Hermes，任务完成后生成交付网址。"
      },
      {
        "title": "闭环比角色数量更关键",
        "text": "文章进一步讨论了钱包、x402 结算，以及按参与情况分配收入的想法。这里要区分已经展示的原型和后续计划：作者明确写到，按 Token 消耗与参与程度分配收入的机制仍待开发。"
      },
      {
        "title": "这篇文章适合怎样阅读",
        "text": "它是一份产品探索记录，适合研究如何把需求、调度、执行、验收与结算连接起来。文中没有证明系统已经获得稳定收入，也不能把原型愿景理解成已成熟运营的接单业务。"
      }
    ],
    "takeaways": [
      "给每个角色明确的输入、输出和交接位置。",
      "先明确什么算交付，再讨论如何分工。",
      "展示原型时，将已实现功能与后续计划分开。"
    ],
    "image": null,
    "alt": "",
    "paragraphs": [],
    "source": "https://x.com/Stellakjbk/status/2054837461336166480",
    "sourceName": "X · 已读取原文",
    "readLabel": "长文导读"
  },
  {
    "slug": "deep-discover-local",
    "category": "本地部署",
    "title": "Deep Discover 研究工作流：从论文核验到 RTX 5090 本地部署",
    "summary": "一次研究型 AI 的完整体验：上传材料、专业分工、草稿综合与独立复核，再把同类流程接到本地模型。",
    "date": "2026-08-28",
    "views": 21233,
    "likes": 113,
    "reposts": 145,
    "bookmarks": 22,
    "original": "https://x.com/Stellakjbk/status/2093179933212504415",
    "kind": "实战长文",
    "sections": [
      {
        "title": "研究为什么需要明确分工",
        "text": "作者用论文与 CSV 作为输入，观察 Deep Discover 如何安排资料读取、外部搜索和分析，再由协调者整合，交给独立复核者检查。文章记录了药物名称混淆被纠正的过程，核心是证据核验，而非医疗结论。"
      },
      {
        "title": "从网页产品走到单卡部署",
        "text": "后半篇记录 Apodex 1.1 mini 的 Int4 版本、SGLang 与 FrontierAgent 在 RTX 5090 32GB 上的组合。作者先固定 32K 上下文和单请求，依次验证普通对话、工具调用、搜索与抓取，再运行多角色研究。"
      },
      {
        "title": "多角色不等于推理吞吐翻倍",
        "text": "本次后端只允许一个生成请求。多个研究者可以交错进行搜索和文件读取，但模型推理仍要排队。文章强调的收益是任务隔离、上下文分工与错误检查，不能把它解释为单卡获得数倍生成速度。"
      },
      {
        "title": "质量来自最后一道复核",
        "text": "本地研究案例中，独立复核者找出了数值矛盾和一条无法验证的说法，随后修正报告。部署版本与性能均属于作者当次记录；完整命令和环境背景请结合原文阅读。"
      }
    ],
    "takeaways": [
      "把资料、事实、分析假设和复核结果分层。",
      "给子任务设置范围、报告长度和停止条件。",
      "对关键结论安排独立检查，并保留未验证标记。"
    ],
    "image": null,
    "alt": "",
    "paragraphs": [],
    "source": "https://x.com/Stellakjbk/status/2093179933212504415",
    "sourceName": "X · 已读取原文",
    "readLabel": "长文导读"
  },
  {
    "slug": "ling-fin-research",
    "category": "研究方法",
    "title": "用两份财报展开一条产业链：Ling 金融模型体验",
    "summary": "从 NVIDIA 与 AAOI 的材料出发，把孤立数字变成连续研究问题，观察长上下文与追问如何服务证据整理。",
    "date": "2026-09-03",
    "views": 5941,
    "likes": 41,
    "reposts": 17,
    "bookmarks": 9,
    "original": "https://x.com/Stellakjbk/status/2095506890763710494",
    "kind": "研究长文",
    "sections": [
      {
        "title": "从总结财报到提出下一问",
        "text": "作者最初只是让 Ling-3.0-Flash-Fin 阅读两份财报，随后不断追问收入、产品代际、扩产、需求与客户架构之间的关系。最终关注点从一家公司延伸到高速光通信产业链。"
      },
      {
        "title": "长上下文的实际用途",
        "text": "文章将长上下文理解为共同的研究现场：财报、电话会、演示材料、客户和供应商信息可以在同一段研究里互相对照。价值不只是一次输入更多文字，而是能否保留材料之间的联系。"
      },
      {
        "title": "允许问题随着证据变化",
        "text": "原文描述，研究由 Rubin 与光模块逐渐走向 1.6T、可插拔方案与 CPO。作者更重视模型能否帮助判断下一步查什么，而不是首次就给出一篇看起来完整的报告。"
      },
      {
        "title": "保留尚未解决的问题",
        "text": "作者同时列出技术路线、同行扩产、价格、良率和供需变化等不确定因素。本站介绍的是资料组织与连续追问的方法，不将文中的产业判断转化为当前投资建议或已经证实的预测。"
      }
    ],
    "takeaways": [
      "把客户与供应商的材料放在一起核对。",
      "每个关键数字后面继续追问原因、时间和证据。",
      "在报告中保留未解决的问题，避免强行收束结论。"
    ],
    "image": null,
    "alt": "",
    "paragraphs": [],
    "source": "https://x.com/Stellakjbk/status/2095506890763710494",
    "sourceName": "X · 已读取原文",
    "readLabel": "长文导读"
  }
];
export const posts:Post[]=[...longPosts,...creativePosts.slice(0,3).map(p=>({...p,category:'创作实验'}))];
export const categories=['全部文章','本地部署','模型评测','Agent 工作流','研究方法','创作实验'];