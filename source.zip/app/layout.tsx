import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'九尾狐 · FoxFairy｜AI 实战与深度笔记',description:'整理自 @Stellakjbk 公开帖子的创作笔记：本地部署、模型评测、Agent 工作流与研究方法。',icons:{icon:"/favicon.svg"},metadataBase:new URL('https://stellakjbk.top')};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="zh-CN"><body>{children}</body></html>}